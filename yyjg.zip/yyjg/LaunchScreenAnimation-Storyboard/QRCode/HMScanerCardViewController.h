//
//  HMScanerCardViewController.h
//  HMQRCodeScanner
//
//  Created by 刘凡 on 16/1/3.
//  Copyright © 2016年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMScanerCardViewController : UIViewController

- (instancetype)initWithCardName:(NSString *)cardName avatar:(UIImage *)avatar;

@end
