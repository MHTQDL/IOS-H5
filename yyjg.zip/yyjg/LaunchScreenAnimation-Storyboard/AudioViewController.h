//
//  AudioViewController.h
//  yyjg
//
//  Created by 莫浩天 on 2017/7/31.
//  Copyright © 2017年 Cave. All rights reserved.
//

#import <UIKit/UIKit.h>
//委托方创建一个协议
@protocol passAudioViewControllerDelegate <NSObject>
//协议定义
-(void)passAudioViewControllerVlaue:(NSString *) strID docUrl:(NSString*) strURL;

@end
@interface AudioViewController : UIViewController
//定义持有协议的id指针
@property (weak)id<passAudioViewControllerDelegate>delegate;
@end
