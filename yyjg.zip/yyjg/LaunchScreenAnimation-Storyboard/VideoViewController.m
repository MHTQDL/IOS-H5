//
//  VideoViewController.m
//  yyjg
//
//  Created by 莫浩天 on 2017/7/31.
//  Copyright © 2017年 Cave. All rights reserved.
//

#import "VideoViewController.h"
#import "DataProcessing.h"
#import "AFNetworking.h"
#import "KZVideoViewController.h"
#import "KZVideoPlayer.h"
@interface VideoViewController ()<KZVideoViewControllerDelegate>{
KZVideoModel *_videoModel;
}
@property (weak, nonatomic) IBOutlet UIView *showView;
@property (weak, nonatomic) IBOutlet UILabel *videoSizeLable;
@property (weak, nonatomic) IBOutlet UIButton *startBtn;//录制
@property (weak, nonatomic) IBOutlet UIButton *uploadBtn;//上传
@property (weak, nonatomic) IBOutlet UIButton *backBtn;//返回
@property (nonatomic, strong) DataProcessing *dataProcessing;
@end

@implementation VideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataProcessing =[DataProcessing manageCenter];
}
- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - KZVideoViewControllerDelegate
- (void)videoViewController:(KZVideoViewController *)videoController didRecordVideo:(KZVideoModel *)videoModel {
    _videoModel = videoModel;
    
    NSError *error = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *attri = [fm attributesOfItemAtPath:_videoModel.videoAbsolutePath error:&error];
    if (error) {
        NSLog(@"error:%@",error);
    }
    else {
        self.videoSizeLable.text = [NSString stringWithFormat:@"视频总大小:%.0fKB",attri.fileSize/1024.0];
    }
    
    for (UIView *subview in self.showView.subviews) {
        [subview removeFromSuperview];
    }
    
    NSURL *videoUrl = [NSURL fileURLWithPath:_videoModel.videoAbsolutePath];
    KZVideoPlayer *player = [[KZVideoPlayer alloc] initWithFrame:self.showView.bounds videoUrl:videoUrl];
    [self.showView addSubview:player];
    
}
//视频录制
- (IBAction)recordFullScreen:(id)sender {
    for (UIView *subview in self.showView.subviews) {
        [subview removeFromSuperview];
    }
    KZVideoViewController *videoVC = [[KZVideoViewController alloc] init];
    videoVC.delegate = self;
    [videoVC startAnimationWithType:KZVideoViewShowTypeSingle];
}

- (IBAction)uploadVideo:(id)sender {
    
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:_videoModel.videoAbsolutePath]){
        self.videoSizeLable.text =@"请录制视频";
        return;
    }
    
    // 实例化NSDateFormatter
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日期格式
    [formatter setDateFormat:@"yyyymmddHHmmss"];
    // 获取当前日期
    NSDate *currentDate = [NSDate date];
    NSString *currentDateString = [formatter stringFromDate:currentDate];
    
    NSString *fileName =[NSString stringWithFormat:@"%@_video.mov",currentDateString];
    
    [self.backBtn setUserInteractionEnabled:false];
    [self.startBtn setUserInteractionEnabled:false];
    [self.uploadBtn setUserInteractionEnabled:false];
    NSDictionary *params=@{@"token":[self.dataProcessing objectForKey:@"uploadUrlToken"]};
    [self uploadFile:[self.dataProcessing objectForKey:@"uploadUrl"]
          uploadFilePath:[NSURL URLWithString:[NSString stringWithFormat:@"file://%@",_videoModel.videoAbsolutePath]] fileName:fileName mimeType:@"audio/wav" parameters:params];
    
    
    
}

/// 上传文件 地址  文件路径 文件名称 文件类型 附加参数
-(void)uploadFile:(NSString*) URLString uploadFilePath:(NSURL*) uploadFilePath fileName:(NSString*) fileName mimeType:(NSString*) mimeType parameters:(NSDictionary *) parameters{
    
    //    NSDictionary *params=@{@"token":@"mobileuploadfile"};
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileURL:uploadFilePath name:@"file" fileName:fileName mimeType:mimeType error:nil];
    } error:nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          NSLog(@"Progress:%f",uploadProgress.fractionCompleted);
                          NSString *str = [NSString stringWithFormat:@"上传进度%2.f%%",uploadProgress.fractionCompleted*100];
                          self.videoSizeLable.text = str;
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          [self.backBtn setUserInteractionEnabled:true];
                          [self.startBtn setUserInteractionEnabled:true];
                          [self.uploadBtn setUserInteractionEnabled:true];
                          self.videoSizeLable.text = @"上传失败！";
                      } else {
                          NSLog(@"response=%@   responseObject=%@", response, responseObject);
                          NSDictionary *dictionary =[[responseObject objectForKey:@"file_info"] firstObject];;
                          [self.delegate passVideoViewControllerVlaue:[dictionary objectForKey:@"id"] docUrl:[dictionary objectForKey:@"docUrl"]];
                          [self.backBtn setUserInteractionEnabled:true];
                          [self.startBtn setUserInteractionEnabled:true];
                          [self.uploadBtn setUserInteractionEnabled:true];
                          self.videoSizeLable.text = @"上传成功！";
                          [self dismissViewControllerAnimated:YES completion:nil];
                      }
                  }];
    
    [uploadTask resume];
    
}

//屏幕点击触发
//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
//{
//    
//}


@end
