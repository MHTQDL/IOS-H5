//
//  ViewController.m
//  yyjg
//
//  Created by SpawNmHt7nOthing on 16/3/28.
//  Copyright © 2016年 SpawNmHt7nOthing. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import <CoreLocation/CoreLocation.h>
#import "DataProcessing.h"
#import "HMScannerController.h"
#import <AVFoundation/AVFoundation.h>
#import "AFNetworking.h"
#import "VideoViewController.h"
#import "AudioViewController.h"

# define COUNTDOWN 60
@interface ViewController ()<WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate,CLLocationManagerDelegate,UINavigationControllerDelegate,UIDocumentInteractionControllerDelegate,passAudioViewControllerDelegate,passVideoViewControllerDelegate>{
    NSString *filePath;//路径
    BOOL animation;
    
}
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) CLLocationManager* locationManager;
@property (nonatomic,strong)UIDocumentInteractionController *docController;
@property (nonatomic, strong) UIView *launchView;

@property (nonatomic, strong) NSURL *downloadFilePath; //下载文件地址
@property (nonatomic, strong) DataProcessing *dataProcessing;


@end

@implementation ViewController


- (void)viewDidLoad {
    self.dataProcessing =[DataProcessing manageCenter];
    animation = YES;
    [super viewDidLoad];
    self.navigationController.delegate = self;
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.preferences.minimumFontSize = 10;
    config.processPool = [[WKProcessPool alloc] init];
    config.userContentController = [[WKUserContentController alloc] init];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelGet"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelPut"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelScan"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelPrint"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelDownload"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelAudioRecord"];
    [config.userContentController addScriptMessageHandler:self name:@"AppModelVideo"];
    
    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) configuration:config];
    
    self.webView.navigationDelegate = self;
    
    
//    NSURL *path = [NSURL URLWithString:@"http://192.168.2.102:8080/yyjg/phoneS/pages/login.html"];
//    NSURL *path = [NSURL URLWithString:@"http://192.168.2.105:8080/yyjg/phoneS/pages/login.html"];
    NSURL *path = [NSURL URLWithString:@"http://yyzf.ostest.jg.yihecloud.net/phoneS/pages/login.html"];
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:path]];
    [self.view addSubview:self.webView];

}
/// 交互
#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    NSArray *array = message.body;
    if ([@"AppModelPut" isEqualToString:message.name]) {
        if([@"userName" isEqualToString:array.firstObject] || [@"password" isEqualToString:array.firstObject]){
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:array.lastObject forKey:array.firstObject];
        }else{
            [self.dataProcessing setObject:array.lastObject forKey:array.firstObject];
        }
    }else if ([@"AppModelGet" isEqualToString:message.name]){
        if([@"userName" isEqualToString:array.firstObject] || [@"password" isEqualToString:array.firstObject]){
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSString *value = @"";
            if(!([defaults objectForKey:array.firstObject]  == nil)){
                value = [defaults objectForKey:array.firstObject];
            }
            NSString *str = [NSString stringWithFormat:@"%@('%@')",array.lastObject,value];
            [self.webView evaluateJavaScript:str completionHandler:nil];
        }else{
            NSString *str = [NSString stringWithFormat:@"%@('%@')",array.lastObject,[self.dataProcessing objectForKey:array.firstObject]];
            [self.webView evaluateJavaScript:str completionHandler:nil];
        }
        
    }else if([@"AppModelScan" isEqualToString:message.name]){
        [self scan];
    }else if([@"AppModelPrint" isEqualToString:message.name]){
        NSURL *url = [[NSURL alloc] initWithString: array.firstObject];
        [[UIApplication sharedApplication] openURL:url];
    }else if([@"AppModelDownload" isEqualToString:message.name]){
        
        if([self.dataProcessing objectForKey:@"DownloadURL"]  == nil){
            [self.dataProcessing setObject:array.firstObject forKey:@"DownloadURL"];
            [self downloadFile:[[NSURL alloc] initWithString: array.firstObject]];
        }else{
            if([[self.dataProcessing objectForKey:@"DownloadURL"] isEqualToString:array.firstObject]){
                [self openFile:self.downloadFilePath];
            }else{
                [self.dataProcessing setObject:array.firstObject forKey:@"DownloadURL"];
                [self downloadFile:[[NSURL alloc] initWithString: array.firstObject]];
            }
            
        }
        
        
    }else if([@"AppModelAudioRecord" isEqualToString:message.name]){
        
        AudioViewController *audioViewController = [[UIStoryboard storyboardWithName:@"AudioViewController" bundle:nil] instantiateViewControllerWithIdentifier:@"AudioViewController"];
        audioViewController.delegate=self;
        [self presentViewController:audioViewController animated:YES completion:nil];
        
    }else if([@"AppModelVideo" isEqualToString:message.name]){
        
        VideoViewController *videoViewController = [[UIStoryboard storyboardWithName:@"VideoViewController" bundle:nil] instantiateViewControllerWithIdentifier:@"VideoViewController"];
        videoViewController.delegate=self;
        [self presentViewController:videoViewController animated:YES completion:nil];
        
    }
}

//代理方
-(void) passAudioViewControllerVlaue:(NSString *) strID docUrl:(NSString*) strURL {
    NSString *str = [NSString stringWithFormat:@"uploadSuccess('%@','%@')",strID,strURL];
    [self.webView evaluateJavaScript:str completionHandler:nil];
}
-(void) passVideoViewControllerVlaue:(NSString *) strID docUrl:(NSString*) strURL{
    NSString *str = [NSString stringWithFormat:@"uploadSuccess('%@','%@')",strID,strURL];
    [self.webView evaluateJavaScript:str completionHandler:nil];
}


/// 页面显示前
-(void)viewWillAppear:(BOOL)animated{
    
    self.navigationController.navigationBar.hidden=YES;
    
}
-(void)viewDidDisappear:(BOOL)animated{
    
    self.navigationController.navigationBar.hidden=YES;
    
}


- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    
}

/// 开始加载时调用
-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{

}
/// 当内容开始返回时调用
-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{

}
/// 页面加载完成之后调用
-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    
    [UIView animateWithDuration:1.0f delay:0.5f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
            self.launchView.alpha = 0.0f;
            self.launchView.layer.transform = CATransform3DScale(CATransform3DIdentity, 2.0f, 2.0f, 1.0f);
        } completion:^(BOOL finished) {
            [self.launchView removeFromSuperview];
    }];
}
/// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    
//    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"警告" message:@"服务器连接失败" preferredStyle:UIAlertControllerStyleAlert];
//    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        
//    }]];
//    [self presentViewController:alert animated:YES completion:nil];
    
    [self.launchView removeFromSuperview];
}




/// app启动 动画
- (void)viewDidAppear:(BOOL)animated {
    if(animation){
        [super viewDidAppear:animated];
        [self launchAnimation];
        animation =NO;
    }
}

#pragma mark - Private Methods
- (void)launchAnimation {
    UIViewController *viewController = [[UIStoryboard storyboardWithName:@"LaunchScreen" bundle:nil] instantiateViewControllerWithIdentifier:@"LaunchScreen"];
    
    self.launchView = viewController.view;
    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
     self.launchView.frame = [UIApplication sharedApplication].keyWindow.frame;
    [mainWindow addSubview: self.launchView];
}




#pragma mark-> 二维码扫描
-(void)scan{
    NSString *str = [NSString stringWithFormat:@"%@('%@')",@"javacalljswithargs",@""];
    [self.webView evaluateJavaScript:str completionHandler:nil];
    HMScannerController *scanner = [HMScannerController scannerWithCardName:nil avatar:nil completion:^(NSString *stringValue) {
        [[UIApplication sharedApplication] openURL:[[NSURL alloc] initWithString: stringValue]];
    }];
    
    [scanner setTitleColor:[UIColor whiteColor] tintColor:[UIColor redColor]];
    
    [self showDetailViewController:scanner sender:nil];
    
}
#pragma mark-> 下载文件
-(void)downloadFile:(NSURL *) URL{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull uploadProgress) {
        // This is not called back on the main queue.
        // You are responsible for dispatching to the main queue for UI updates
        dispatch_async(dispatch_get_main_queue(), ^{
            //Update the progress view
            NSLog(@"Progress:%f",uploadProgress.fractionCompleted*100);
        });
    }
    destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
            return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
        } completionHandler:^(NSURLResponse *response, NSURL *downloadFilePath, NSError *error) {
            if(error){
                NSString *str = [NSString stringWithFormat:@"downloadFileError('%@')",@""];
                [self.webView evaluateJavaScript:str completionHandler:nil];
            }else{
                self.downloadFilePath =downloadFilePath;
                [self openFile:downloadFilePath];
            }
        }];
    [downloadTask resume];
}



#pragma mark-> 第三方应用打开文件
- (void)openFile:(NSURL*) fileURL{
    NSString *str = [NSString stringWithFormat:@"viewFileLoadSuccess('%@')",@""];
    [self.webView evaluateJavaScript:str completionHandler:nil];
    _docController = [UIDocumentInteractionController interactionControllerWithURL:fileURL];
    
    _docController.delegate =self;
    
    [_docController presentOptionsMenuFromRect:self.view.bounds inView:self.view animated:YES];
}

#pragma mark-> 清理缓存
/// 在ViewController销毁时移除KVO观察者，同时清除所有的html缓存
- (void)dealloc {
    [self.webView removeObserver:self forKeyPath:@"estimatedProgress"];
    [self.webView removeObserver:self forKeyPath:@"title"];
    [self clearCache];
}

/** 清理缓存的方法，这个方法会清除缓存类型为HTML类型的文件*/
- (void)clearCache {
    /* 取得Library文件夹的位置*/
    NSString *libraryDir = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask, YES)[0];
    /* 取得bundle id，用作文件拼接用*/
    NSString *bundleId  =  [[[NSBundle mainBundle] infoDictionary]objectForKey:@"CFBundleIdentifier"];
    /*
     * 拼接缓存地址，具体目录为App/Library/Caches/你的APPBundleID/fsCachedData
     */
    NSString *webKitFolderInCachesfs = [NSString stringWithFormat:@"%@/Caches/%@/fsCachedData",libraryDir,bundleId];
    
    NSError *error;
    /* 取得目录下所有的文件，取得文件数组*/
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //    NSArray *fileList = [[NSArray alloc] init];
    //fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
    NSArray *fileList = [fileManager contentsOfDirectoryAtPath:webKitFolderInCachesfs error:&error];
    /* 遍历文件组成的数组*/
    for(NSString * fileName in fileList){
        /* 定位每个文件的位置*/
        NSString * path = [[NSBundle bundleWithPath:webKitFolderInCachesfs] pathForResource:fileName ofType:@""];
        /* 将文件转换为NSData类型的数据*/
        NSData * fileData = [NSData dataWithContentsOfFile:path];
        /* 如果FileData的长度大于2，说明FileData不为空*/
        if(fileData.length >2){
            /* 创建两个用于显示文件类型的变量*/
            int char1 =0;
            int char2 =0;
            
            [fileData getBytes:&char1 range:NSMakeRange(0,1)];
            [fileData getBytes:&char2 range:NSMakeRange(1,1)];
            /* 拼接两个变量*/
            NSString *numStr = [NSString stringWithFormat:@"%i%i",char1,char2];
            /* 如果该文件前四个字符是6033，说明是Html文件，删除掉本地的缓存*/
            if([numStr isEqualToString:@"6033"]){
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/%@",webKitFolderInCachesfs,fileName]error:&error];
                continue;
            }
        }
    }
}

@end
