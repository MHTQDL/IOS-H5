//
//  VideoViewController.h
//  yyjg
//
//  Created by 莫浩天 on 2017/7/31.
//  Copyright © 2017年 Cave. All rights reserved.
//

#import <UIKit/UIKit.h>
//委托方创建一个协议
@protocol passVideoViewControllerDelegate <NSObject>
//协议定义
-(void)passVideoViewControllerVlaue:(NSString *) strID docUrl:(NSString*) strURL;

@end
@interface VideoViewController : UIViewController
//定义持有协议的id指针
@property (weak)id<passVideoViewControllerDelegate>delegate;
@end
