//
//  AudioViewController.m
//  yyjg
//
//  Created by 莫浩天 on 2017/7/31.
//  Copyright © 2017年 Cave. All rights reserved.
//

#import "AudioViewController.h"
#import "DataProcessing.h"
#import "AFNetworking.h"
#import <AVFoundation/AVFoundation.h>

# define COUNTDOWN 300

@interface AudioViewController (){
    NSTimer *_timer; //定时器
    NSInteger countDown;  //倒计时
    NSString *recordfilePath;//录音路径
}
@property (weak, nonatomic) IBOutlet UILabel *text;
/// 录音
@property (nonatomic, strong) AVAudioSession *session;
@property (nonatomic, strong) AVAudioRecorder *recorder;//录音器
@property (nonatomic, strong) AVAudioPlayer *player; //播放器
@property (nonatomic, strong) NSURL *recordFileUrl; //录音文件地址
@property (weak, nonatomic) IBOutlet UIButton *startBtn;//开始录音
@property (weak, nonatomic) IBOutlet UIButton *uploadBtn;//上传
@property (weak, nonatomic) IBOutlet UIButton *backBtn;//返回
@property (nonatomic, strong) DataProcessing *dataProcessing;//全局map
@end


@implementation AudioViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataProcessing =[DataProcessing manageCenter];
}

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/// 开始录音
- (IBAction)startRecord:(id)sender {
    if ([self.recorder isRecording]) {
        return;
    }
    
    
    countDown = COUNTDOWN;
    [self addTimer];
    
    AVAudioSession *session =[AVAudioSession sharedInstance];
    NSError *sessionError;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    
    if (session == nil) {
        
        NSLog(@"Error creating session: %@",[sessionError description]);
        
    }else{
        [session setActive:YES error:nil];
        
    }
    
    self.session = session;
    
    
    //1.获取沙盒地址
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    recordfilePath = [path stringByAppendingString:@"/audio.wav"];
    NSLog(@"%@",recordfilePath);
    
    //2.获取文件路径
    self.recordFileUrl = [NSURL fileURLWithPath:recordfilePath];
    //设置参数
    NSDictionary *recordSetting = [[NSDictionary alloc] initWithObjectsAndKeys:
                                   //采样率  8000/11025/22050/44100/96000（影响音频的质量）
                                   [NSNumber numberWithFloat: 8000.0],AVSampleRateKey,
                                   // 音频格式
                                   [NSNumber numberWithInt: kAudioFormatLinearPCM],AVFormatIDKey,
                                   //采样位数  8、16、24、32 默认为16
                                   [NSNumber numberWithInt:16],AVLinearPCMBitDepthKey,
                                   // 音频通道数 1 或 2
                                   [NSNumber numberWithInt: 1], AVNumberOfChannelsKey,
                                   //录音质量
                                   [NSNumber numberWithInt:AVAudioQualityHigh],AVEncoderAudioQualityKey,
                                   nil];
    
    
    _recorder = [[AVAudioRecorder alloc] initWithURL:self.recordFileUrl settings:recordSetting error:nil];
    
    if (_recorder) {
        
        _recorder.meteringEnabled = YES;
        [_recorder prepareToRecord];
        [_recorder record];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [self stopRecord:nil];
        });
        
        
        
    }else{
        NSLog(@"音频格式和文件存储格式不匹配,无法初始化Recorder");
        
    }
}
/// 停止录音
- (IBAction)stopRecord:(id)sender {
    
    [self removeTimer];
    
    if ([self.recorder isRecording]) {
        [self.recorder stop];
    }
    
    
    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:recordfilePath]){
        ///反显
        NSString *str = [NSString stringWithFormat:@"录了 %ld 秒,文件大小为 %.2fKb",COUNTDOWN - (long)countDown,[[manager attributesOfItemAtPath:recordfilePath error:nil] fileSize]/1024.0];
        self.text.text = str;
    }else{
        ///反显
        NSString *str = [NSString stringWithFormat:@"最多录%d秒",COUNTDOWN];
        self.text.text = str;
    }
    
}
/// 播放录音
- (IBAction)playRecord:(id)sender{
    
    if ([self.player isPlaying]){
        return;
    }else{
        [self stopRecord:nil];
    }
    
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:self.recordFileUrl error:nil];
    
    [self.session setCategory:AVAudioSessionCategoryPlayback error:nil];
    [self.player play];
    
}
/// 录音上传
- (IBAction)uploadRecord:(id)sender {
    
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:recordfilePath]){
        self.text.text =@"请录制音频";
        return;
    }
    
    [self removeTimer];
    [self.recorder stop];
    
    [self.startBtn setUserInteractionEnabled:false];
    [self.uploadBtn setUserInteractionEnabled:false];
    [self.backBtn setUserInteractionEnabled:false];
    
    
    // 实例化NSDateFormatter
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日期格式
    [formatter setDateFormat:@"yyyymmddHHmmss"];
    // 获取当前日期
    NSDate *currentDate = [NSDate date];
    NSString *currentDateString = [formatter stringFromDate:currentDate];
    
    NSString *fileName =[NSString stringWithFormat:@"%@_audio.wav",currentDateString];
    
    NSLog(@"%@",self.recordFileUrl);
    NSDictionary *params=@{@"token":[self.dataProcessing objectForKey:@"uploadUrlToken"]};
    [self uploadFile:[self.dataProcessing objectForKey:@"uploadUrl"]
      uploadFilePath:self.recordFileUrl fileName:fileName mimeType:@"audio/wav" parameters:params];
}
///添加定时器
- (void)addTimer
{
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(refreshCountDown) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}
///移除定时器
- (void)removeTimer
{
    [_timer invalidate];
    _timer = nil;
    
}
/// 反显计时
-(void)refreshCountDown{
    
    countDown --;
    NSString *str = [NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"还剩 %ld 秒",(long)countDown]];
    self.text.text = str;
}

/// 上传文件 地址  文件路径 文件名称 文件类型 附加参数
-(void)uploadFile:(NSString*) URLString uploadFilePath:(NSURL*) uploadFilePath fileName:(NSString*) fileName mimeType:(NSString*) mimeType parameters:(NSDictionary *) parameters{
    
    //    NSDictionary *params=@{@"token":@"mobileuploadfile"};
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileURL:uploadFilePath name:@"file" fileName:fileName mimeType:mimeType error:nil];
    } error:nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          NSLog(@"Progress:%f",uploadProgress.fractionCompleted);
                          NSString *str = [NSString stringWithFormat:@"上传进度%2.f%%",uploadProgress.fractionCompleted*100];
                          self.text.text = str;
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          [self.startBtn setUserInteractionEnabled:true];
                          [self.uploadBtn setUserInteractionEnabled:true];
                          [self.backBtn setUserInteractionEnabled:true];
                          self.text.text = @"上传失败！";
                      } else {
                          NSLog(@"response=%@   responseObject=%@", response, responseObject);
                          NSDictionary *dictionary =[[responseObject objectForKey:@"file_info"] firstObject];;
                          [self.delegate passAudioViewControllerVlaue:[dictionary objectForKey:@"id"] docUrl:[dictionary objectForKey:@"docUrl"]];
                          [self.startBtn setUserInteractionEnabled:true];
                          [self.uploadBtn setUserInteractionEnabled:true];
                          [self.backBtn setUserInteractionEnabled:true];
                          self.text.text = @"上传成功！";
                          [self dismissViewControllerAnimated:YES completion:nil];
                      }
                  }];
    
    [uploadTask resume];
    
}
@end
